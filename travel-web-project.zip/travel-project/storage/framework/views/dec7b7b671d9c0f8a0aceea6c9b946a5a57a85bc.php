<?php $__env->startSection('content'); ?>
<div class="container">
    <br>
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    Hi <b><?php echo e(Auth::user()->name); ?></b>! <?php echo e(__('Bạn đã đăng nhập vào website!')); ?>

                </b>
                </div>
        </div>
    </div>
    </div>
    <br>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Desktop\PROJECT\travel-project\resources\views/home.blade.php ENDPATH**/ ?>