<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <style>
        body{
            background-image: url('images/avatars/background.jpg');
        }
    </style>
</head>
<body style="background-image: url('images/avatars/background.jpg')">
    <form role="form" class="form-horizontal" method="post" action="" enctype="multipart/form-data">
        <div class="container">
        <?php echo csrf_field(); ?>
            <center><h2>Update Tour</h2></center>
            <div class="form-group">
                <label for="formGroupExampleInput">Title</label>
                <input type="text" name="title" value="<?php echo $tour['title']; ?>" class="form-control" >
            </div>
            <div class="form-group">
                <label for="formGroupExampleInput">Summarize</label>
                <input type="text" name="summarize" value="<?php echo $tour['summarize']; ?>" class="form-control" placeholder="">
            </div>
            <div class="form-group">
                <label for="formGroupExampleInput">Content</label>
                <input type="text" name="content" value="<?php echo $tour['content']; ?>" class="form-control" placeholder="">
            </div>
            <div class="form-group">
                <label for="formGroupExampleInput">Type Tour</label>
                <select name="typetour" id="" class="form-control">
                    <?php $__currentLoopData = $type_tour; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type_prds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($type_prds->id); ?>"
                        <?php if($type_prds->id==$tour['id_type']): ?>
                            selected
                        <?php endif; ?>>
                        <?php echo e($type_prds->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="formGroupExampleInput2">Price</label>
                <input type="text" name="price" value="<?php echo $tour['price']; ?>" class="form-control" placeholder="">
            </div>
            <div class="form-group">
                <label for="formGroupExampleInput">On Sale</label>
                <input type="text" name="onsale" value="<?php echo $tour['on_sale']; ?>" class="form-control" placeholder="">
            </div>
            <div class="form-group">
                <label for="formGroupExampleInput2">Schedule</label>
                <input type="text" name="schedule" value="<?php echo $tour['schedule']; ?>" class="form-control" placeholder="">
            </div>
            <div class="form-group">
                <label for="formGroupExampleInput2">Image</label>
                <input type="file" name="image" id="image" value="<?php echo $tour['image']; ?>" class="form-control" placeholder="">
            </div>
            <div>
				<?php echo $__env->make('blocks.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			</div>
            <button type="submit" name="update" class="btn btn-primary">Update</button>
        </div>
    </form>
</body><?php /**PATH C:\Users\Admin\Desktop\PROJECT\travel-project\resources\views/page/editTour.blade.php ENDPATH**/ ?>