<?php $__env->startSection('content'); ?>
<?php echo $__env->make('blocks.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<head>
    <title>Trang chủ</title>
</head>
<div class="breadcrumbs">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="bread-inner">
                    <ul class="bread-list">
                        <li class="active"><a href="<?php echo e(url('/')); ?>">TRANG CHỦ</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<br>
<div class="container">
<div id="carousel-thumb" class="carousel slide carousel-fade carousel-thumbnails" data-ride="carousel">
  <!--Slides-->
  <div class="carousel-inner" role="listbox">
    <?php $__currentLoopData = $slide; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($sl->id ==1): ?>
    <div class="carousel-item active">
    <?php else: ?>
    <div class="carousel-item">
    <?php endif; ?>
      <img class="d-block w-100" src="<?php echo e(URL::asset($sl->image)); ?>"
        alt="<?php echo e($sl->name); ?>" height="400px">
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  <a class="carousel-control-prev" href="#carousel-thumb" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carousel-thumb" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
</div>
<br/>
<div class="container">

    <div class="row">
    <div class="col-12 col-sm-3">

    <div class="card bg-light mb-3">
        <div class="card-header bg-success text-white text-uppercase">CÁC LOẠI TOUR DU LỊCH</div>
        <div class="card-body">
            <ul class="categor-list">
                <?php $__currentLoopData = $type_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type_prds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><a href="<?php echo e(route('type-product',$type_prds->id)); ?>"><?php echo e($type_prds->name); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        </div>
    </div>
    <br/>

    <div class="col">
        <br/>
        <?php if($last_tour->count()<>0): ?>
        <h4 style="color:red">Tours trăng mật</h4>
        <div class="row">
            <?php if($last_tour->count()<>0): ?>
            <?php $__currentLoopData = $last_tour; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-md-6 col-12">
                <div class="single-product">
                    <div class="product-img">
                        <a href="<?php echo e(route('product-detail',$prds->id)); ?>">
                            <img height="200px" src="<?php echo e(URL::asset($prds->image)); ?>" alt="<?php echo e($prds->title); ?>">
                            <img class="hover-img" src="<?php echo e(URL::asset($prds->image)); ?>" alt="<?php echo e($prds->title); ?>">
                            <?php $__currentLoopData = $type_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type_prds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php switch($prds->id_type):
                                case ($type_prds->id): ?>
                                    <span class="new"><?php echo e($type_prds->name); ?></span>
                                    <?php break; ?>
                                    <?php default: ?>
                                <?php endswitch; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </a>
                        <div class="button-head">
                            <div class="product-action">
                                <a title="Xem thêm" href="<?php echo e(route('product-detail',$prds->id)); ?>"><i class=" ti-eye"></i><span>Xem thêm</span></a>
                                </div>
                            <div class="product-action-2">
                                <a title="Đặt tour" href="<?php echo e(url('book-tour-histories',$prds->id)); ?>">Đặt tour</a>
                            </div>
                        </div>
                    </div>
                    <div class="product-content">
                        <h3><a href="<?php echo e(route('product-detail',$prds->id)); ?>"><?php echo e($prds->title); ?></a></h3>
                        <div class="product-price">
                            <div class="spacing">
                                <span><i class="ti-money"></i>Giá:</span>
                                <span>
                                    <?php if($prds->on_sale<>0): ?>
                                    <b style="text-decoration: line-through;">
                                        <?php echo e(number_format($prds->price)); ?>đ
                                    </b>
                                    <b style="color: red">
                                        <?php echo e(' '.number_format($prds->price - (($prds->price*$prds->on_sale)/100))); ?>đ
                                    </b>
                                    <?php else: ?>
                                        <b style="color: red">
                                            <?php echo e(number_format($prds->price)); ?>đ
                                        </b>
                                    <?php endif; ?>
                                </span>
                            </div>

                            <div class="spacing">
                                <span><i class="ti-alarm-clock"></i>Lịch trình:</span>
                                <span><?php echo e($prds->schedule); ?></span>
                            </div>
                            <div class="spacing">
                                <form class="form" action="<?php echo e(route('add-to-favorite',$prds->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?> <button style="padding: 0;
                                    border: none;
                                    background: none;" type="submit"><i class=" ti-heart" style="color: red"></i><span>Yêu thích</span></button>
                                </form>
                                <a href="<?php echo e(url('book-tour-histories',$prds->id)); ?>" ><button type="button" class="btn btn-danger">BOOK NGAY</button></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($last_tour->links()); ?>

            <?php else: ?>
                <div>Không có sản phẩm nào.</div>
            <?php endif; ?>
        </div>
        <br/>
        <?php endif; ?>
        <?php if($promotional_tour->count()<>0): ?>
        <h4 style="color:red">Tours khuyến mãi</h4>
        <div class="row">
            <?php if($promotional_tour->count()<>0): ?>
            <?php $__currentLoopData = $promotional_tour; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-md-6 col-12">
                <div class="single-product">
                    <div class="product-img">
                        <a href="<?php echo e(route('product-detail',$prds->id)); ?>">
                            <img height="200px" src="<?php echo e(URL::asset($prds->image)); ?>" alt="<?php echo e($prds->title); ?>">
                            <img class="hover-img" src="<?php echo e(URL::asset($prds->image)); ?>" alt="<?php echo e($prds->title); ?>">
                            <?php $__currentLoopData = $type_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type_prds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php switch($prds->id_type):
                                case ($type_prds->id): ?>
                                    <span class="new"><?php echo e($type_prds->name); ?></span>
                                    <?php break; ?>
                                    <?php default: ?>
                                <?php endswitch; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </a>
                        <div class="button-head">
                            <div class="product-action">
                                <a title="Xem thêm" href="<?php echo e(route('product-detail',$prds->id)); ?>"><i class=" ti-eye"></i><span>Xem thêm</span></a>
                                </div>
                            <div class="product-action-2">
                                <a title="Đặt tour" href="<?php echo e(url('book-tour-histories',$prds->id)); ?>">Đặt tour</a>
                            </div>
                        </div>
                    </div>
                    <div class="product-content">
                        <h3><a href="<?php echo e(route('product-detail',$prds->id)); ?>"><?php echo e($prds->title); ?></a></h3>
                        <div class="product-price">
                            <div class="spacing">
                                <span><i class="ti-money"></i>Giá:</span>
                                <span>
                                    <?php if($prds->on_sale<>0): ?>
                                    <b style="text-decoration: line-through;">
                                        <?php echo e(number_format($prds->price)); ?>đ
                                    </b>
                                    <b style="color: red">
                                        <?php echo e(' '.number_format($prds->price - (($prds->price*$prds->on_sale)/100))); ?>đ
                                    </b>
                                    <?php else: ?>
                                        <b style="color: red">
                                            <?php echo e(number_format($prds->price)); ?>đ
                                        </b>
                                    <?php endif; ?>
                                </span>
                            </div>

                            <div class="spacing">
                                <span><i class="ti-alarm-clock"></i>Lịch trình:</span>
                                <span><?php echo e($prds->schedule); ?></span>
                            </div>
                            <div class="spacing">
                                <form class="form" action="<?php echo e(route('add-to-favorite',$prds->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?> <button style="padding: 0;
                                    border: none;
                                    background: none;" type="submit"><i class=" ti-heart" style="color: red"></i><span>Yêu thích</span></button>
                                </form>
                                <a href="<?php echo e(url('book-tour-histories',$prds->id)); ?>" ><button type="button" class="btn btn-danger">Book ngay</button></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($promotional_tour->links()); ?>

            <?php else: ?>
                <div>Không có sản phẩm nào.</div>
            <?php endif; ?>
        </div>
        <br/>
        <?php endif; ?>
        <?php if($cheap_tour->count()<>0): ?>
        <h4 style="color:red">Tours giá rẻ</h4>
        <div class="row">
            <?php if($cheap_tour->count()<>0): ?>
            <?php $__currentLoopData = $cheap_tour; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-md-6 col-12">
                <div class="single-product">
                    <div class="product-img">
                        <a href="<?php echo e(route('product-detail',$prds->id)); ?>">
                            <img height="200px" src="<?php echo e(URL::asset($prds->image)); ?>" alt="<?php echo e($prds->title); ?>">
                            <img class="hover-img" src="<?php echo e(URL::asset($prds->image)); ?>" alt="<?php echo e($prds->title); ?>">
                            <?php $__currentLoopData = $type_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type_prds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php switch($prds->id_type):
                                case ($type_prds->id): ?>
                                    <span class="new"><?php echo e($type_prds->name); ?></span>
                                    <?php break; ?>
                                    <?php default: ?>
                                <?php endswitch; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </a>
                        <div class="button-head">
                            <div class="product-action">
                                <a title="Xem thêm" href="<?php echo e(route('product-detail',$prds->id)); ?>"><i class=" ti-eye"></i><span>Xem thêm</span></a>
                            </div>
                            <div class="product-action-2">
                                <a title="Đặt tour" href="<?php echo e(url('book-tour-histories',$prds->id)); ?>">Đặt tour</a>
                            </div>
                        </div>
                    </div>
                    <div class="product-content">
                        <h3><a href="<?php echo e(route('product-detail',$prds->id)); ?>"><?php echo e($prds->title); ?></a></h3>
                        <div class="product-price">
                            <div class="spacing">
                                <span><i class="ti-money"></i>Giá:</span>
                                <span>
                                    <?php if($prds->on_sale<>0): ?>
                                    <b style="text-decoration: line-through;">
                                        <?php echo e(number_format($prds->price)); ?>đ
                                    </b>
                                    <b style="color: red">
                                        <?php echo e(' '.number_format($prds->price - (($prds->price*$prds->on_sale)/100))); ?>đ
                                    </b>
                                    <?php else: ?>
                                        <b style="color: red">
                                            <?php echo e(number_format($prds->price)); ?>đ
                                        </b>
                                    <?php endif; ?>
                                </span>
                            </div>

                            <div class="spacing">
                                <span><i class="ti-alarm-clock"></i>Lịch trình:</span>
                                <span><?php echo e($prds->schedule); ?></span>
                            </div>
                            <div class="spacing">
                                <form class="form" action="<?php echo e(route('add-to-favorite',$prds->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?> <button style="padding: 0;
                                    border: none;
                                    background: none;" type="submit"><i class=" ti-heart" style="color: red"></i><span>Yêu thích</span></button>
                                </form>
                                <a href="<?php echo e(url('book-tour-histories',$prds->id)); ?>" ><button type="button" class="btn btn-danger">BOOK NGAY</button></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($cheap_tour->links()); ?>

            <?php else: ?>
                <div>Không có sản phẩm nào.</div>
            <?php endif; ?>
        </div>
        <br/>
        <?php endif; ?>
        <?php if($family_tour->count()<>0): ?>
        <h4 style="color:red">Tours gia đình</h4>
        <div class="row">
            <?php if($family_tour->count()<>0): ?>
            <?php $__currentLoopData = $family_tour; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-md-6 col-12">
                <div class="single-product">
                    <div class="product-img">
                        <a href="<?php echo e(route('product-detail',$prds->id)); ?>">
                            <img height="200px" src="<?php echo e(URL::asset($prds->image)); ?>" alt="<?php echo e($prds->title); ?>">
                            <img class="hover-img" src="<?php echo e(URL::asset($prds->image)); ?>" alt="<?php echo e($prds->title); ?>">
                            <?php $__currentLoopData = $type_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type_prds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php switch($prds->id_type):
                                case ($type_prds->id): ?>
                                    <span class="new"><?php echo e($type_prds->name); ?></span>
                                    <?php break; ?>
                                    <?php default: ?>
                                <?php endswitch; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </a>
                        <div class="button-head">
                            <div class="product-action">
                                <a title="Xem thêm" href="<?php echo e(route('product-detail',$prds->id)); ?>"><i class=" ti-eye"></i><span>Xem thêm</span></a>
                            </div>
                            <div class="product-action-2">
                                <a title="Đặt tour" href="<?php echo e(url('book-tour-histories',$prds->id)); ?>">Đặt tour</a>
                            </div>
                        </div>
                    </div>
                    <div class="product-content">
                        <h3><a href="<?php echo e(route('product-detail',$prds->id)); ?>"><?php echo e($prds->title); ?></a></h3>
                        <div class="product-price">
                            <div class="spacing">
                                <span><i class="ti-money"></i>Giá:</span>
                                <span>
                                    <?php if($prds->on_sale<>0): ?>
                                    <b style="text-decoration: line-through;">
                                        <?php echo e(number_format($prds->price)); ?>đ
                                    </b>
                                    <b style="color: red">
                                        <?php echo e(' '.number_format($prds->price - (($prds->price*$prds->on_sale)/100))); ?>đ
                                    </b>
                                    <?php else: ?>
                                        <b style="color: red">
                                            <?php echo e(number_format($prds->price)); ?>đ
                                        </b>
                                    <?php endif; ?>
                                </span>
                            </div>

                            <div class="spacing">
                                <span><i class="ti-alarm-clock"></i>Lịch trình:</span>
                                <span><?php echo e($prds->schedule); ?></span>
                            </div>
                            <div class="spacing">
                                <form class="form" action="<?php echo e(route('add-to-favorite',$prds->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?> <button style="padding: 0;
                                    border: none;
                                    background: none;" type="submit"><i class=" ti-heart" style="color: red"></i><span>Yêu thích</span></button>
                                </form>
                                <a href="<?php echo e(url('book-tour-histories',$prds->id)); ?>" ><button type="button" class="btn btn-danger">BOOK NGAY</button></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($family_tour->links()); ?>

            <?php else: ?>
                <div>Không có sản phẩm nào.</div>
            <?php endif; ?>
        </div>
        <br/>
        <?php endif; ?>
        <?php if($featured_tour->count()<>0): ?>
        <h4 style="color:red">Tours nổi bật</h4>
        <div class="row">
            <?php if($featured_tour->count()<>0): ?>
            <?php $__currentLoopData = $featured_tour; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-md-6 col-12">
                <div class="single-product">
                    <div class="product-img">
                        <a href="<?php echo e(route('product-detail',$prds->id)); ?>">
                            <img height="200px" src="<?php echo e(URL::asset($prds->image)); ?>" alt="<?php echo e($prds->title); ?>">
                            <img class="hover-img" src="<?php echo e(URL::asset($prds->image)); ?>" alt="<?php echo e($prds->title); ?>">
                            <?php $__currentLoopData = $type_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type_prds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php switch($prds->id_type):
                                case ($type_prds->id): ?>
                                    <span class="new"><?php echo e($type_prds->name); ?></span>
                                    <?php break; ?>
                                    <?php default: ?>
                                <?php endswitch; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </a>
                        <div class="button-head">
                            <div class="product-action">
                                <a title="Xem thêm" href="<?php echo e(route('product-detail',$prds->id)); ?>"><i class=" ti-eye"></i><span>Xem thêm</span></a>
                            </div>
                            <div class="product-action-2">
                                <a title="Đặt tour" href="<?php echo e(url('book-tour-histories',$prds->id)); ?>">Đặt tour</a>
                            </div>
                        </div>
                    </div>
                    <div class="product-content">
                        <h3><a href="<?php echo e(route('product-detail',$prds->id)); ?>"><?php echo e($prds->title); ?></a></h3>
                        <div class="product-price">
                            <div class="spacing">
                                <span><i class="ti-money"></i>Giá:</span>
                                <span>
                                    <?php if($prds->on_sale<>0): ?>
                                    <b style="text-decoration: line-through;">
                                        <?php echo e(number_format($prds->price)); ?>đ
                                    </b>
                                    <b style="color: red">
                                        <?php echo e(' '.number_format($prds->price - (($prds->price*$prds->on_sale)/100))); ?>đ
                                    </b>
                                    <?php else: ?>
                                        <b style="color: red">
                                            <?php echo e(number_format($prds->price)); ?>đ
                                        </b>
                                    <?php endif; ?>
                                </span>
                            </div>

                            <div class="spacing">
                                <span><i class="ti-alarm-clock"></i>Lịch trình:</span>
                                <span><?php echo e($prds->schedule); ?></span>
                            </div>
                            <div class="spacing">
                                <form class="form" action="<?php echo e(route('add-to-favorite',$prds->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?> <button style="padding: 0;
                                    border: none;
                                    background: none;" type="submit"><i class=" ti-heart" style="color: red"></i><span>Yêu thích</span></button>
                                </form>
                                <a href="<?php echo e(url('book-tour-histories',$prds->id)); ?>" ><button type="button" class="btn btn-danger">BOOK NGAY</button></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($featured_tour->links()); ?>

            <?php else: ?>
                <div>Không có sản phẩm nào.</div>
            <?php endif; ?>
        </div>
         <?php endif; ?>
    </div>
    </div>
</div>
</div>
<br/>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\travel-project\resources\views/page/home.blade.php ENDPATH**/ ?>