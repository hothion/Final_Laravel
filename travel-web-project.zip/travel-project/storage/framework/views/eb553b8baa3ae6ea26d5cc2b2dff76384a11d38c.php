<?php $__env->startSection('content'); ?>
<head>
    <title>Tour Yêu Thích</title>
</head>
<div class="breadcrumbs">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="bread-inner">
                    <ul class="bread-list">
                        <li><a href="<?php echo e(url('/')); ?>">TRANG CHỦ<i class="ti-arrow-right"></i></a></li>
                        <li class="active"><a href="<?php echo e(url('/about-us')); ?>">TOUR YÊU THÍCH</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<?php if(isset(Auth::user()->id)): ?>
<div class="container">
    <br>
    <div class="row profile">
		<div class="col-md-3">
			<div class="profile-sidebar">
				<div class="profile-userpic">
					<img src="<?php echo e(URL::asset('images\avatars\avatar.png')); ?>" class="img-responsive" alt="">
				</div>

				<div class="profile-usertitle">
					<div class="profile-usertitle-name">
                        <div class="spacing">
                            <span><i class="ti-user"></i>Tên:</span>
                            <span><?php echo e(Auth::user()->name); ?></span>
                        </div>
                        <div class="spacing">
                            <span><i class="ti-email"></i>Email:</span>
                            <span><?php echo e(Auth::user()->email); ?></span>
                        </div>
                        <div class="spacing">
                            <span><i class="ti-user"></i>Quyền sử dụng:</span>
                            <span>
                                <?php if(Auth::user()->is_admin==1): ?>
                                    Admin
                                <?php else: ?>
                                    Khách hàng
                                <?php endif; ?>
                            </span>
                        </div>
                        <div class="spacing">
                            <span><i class="ti-lock"></i>Mật khẩu:</span>
                            <span>
                                <b><a style="color: red" href="<?php echo e(route('password.update')); ?>"><?php echo e(__('Đổi mật khẩu')); ?></a></b>
                            </span>
                        </div>
					</div>
				</div>

				<div class="spacing">
                    <form class="form" action="<?php echo e(route('profile')); ?>" method="get">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-danger btn-sm">TRANG CÁ NHÂN</button>
                    </form>
					<form class="form" action="<?php echo e(route('tours')); ?>" method="get">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-danger btn-sm">LỊCH SỬ ĐẶT TOUR CỦA BẠN</button>
                    </form>
				</div>

			</div>
		</div>
		<div class="col-md-9">
            <div class="profile-content">
               CÁC TOUR YÊU THÍCH GẦN ĐÂY CỦA BẠN
               <div>
                <div class="row">
                    <?php $__currentLoopData = $fvr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fvrs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-6 col-12">
                        <?php if(count($fvr)<>0): ?>
                        <div class="single-product">
                            <div class="product-img">
                                <a href="<?php echo e(url('products-detail',$fvrs->idTour)); ?>">
                                    <img height="200px" src="<?php echo e(URL::asset($fvrs->image)); ?>" alt="<?php echo e($fvrs->title); ?>">
                                </a>
                            </div>
                            <div class="product-content">
                                <h3><a href="<?php echo e(url('products-detail',$fvrs->idTour)); ?>"><?php echo e($fvrs->title); ?></a></h3>
                                <div class="product-price">
                                    <div class="spacing">
                                        <span><i class="ti-calendar"></i>Thời gian:</span>
                                        <span><?php echo e(date('j F, Y', strtotime($fvrs->created_at))); ?></span>
                                    </div>
                                    <form id="remove-fvt" class="form" action="<?php echo e(route('remove-favorite',$fvrs->id)); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <a href="#" onclick="document.getElementById('remove-fvt').submit()"><span style="color: red"><i class=" ti-heart" style="color: black"></i>Bỏ yêu thích</span></a>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <?php else: ?>
                            <div>Bạn chưa yêu thích bất kỳ tour du lịch nào.</div>
                        <?php endif; ?>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
               </div>
            </div>
		</div>
    </div>
    <br>
</div>
<?php else: ?>
    <?php echo $__env->make('page/non-login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Desktop\PROJECT\travel-project\resources\views/page/favorite-tour.blade.php ENDPATH**/ ?>