<div class="container">
    <br>
    <div>Bạn chưa đăng nhập vào website. Vui lòng đăng nhập để thực hiện chức năng này.</div>
    <br>
    <?php if(auth()->guard()->guest()): ?>
        <button class=""><a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a></button>
        <?php if(Route::has('register')): ?>
            <button><a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a></button>
        <?php endif; ?>
    <?php endif; ?>
</div>
<br>
<?php /**PATH C:\Users\Admin\Desktop\PROJECT\travel-project\resources\views/page/non-login.blade.php ENDPATH**/ ?>