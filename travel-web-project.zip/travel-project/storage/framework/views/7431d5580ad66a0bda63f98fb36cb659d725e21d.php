<header class="header shop">
    <div class="topbar">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-12 col-12">
                    <div class="top-left">
                        <ul class="list-main">
                            <li><i class="ti-mobile"></i> 0366 908 087</li>
                            <li><i class="ti-email"></i> vnenjoytravel@gmail.com</li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-8 col-md-12 col-12">
                    <div class="right-content">
                        <ul class="list-main">
                            <li><i class="ti-location-pin"></i> 99 Tô Hiến Thành, Sơn Trà, Đà Nẵng</li>
                            <li><i class="ti-alarm-clock"></i> <a href="">24/7</a></li>
                            <li><i class="ti-user"></i> <a href="<?php echo e(url('/profile')); ?>">Tài khoản</a></li>
                            <?php if(auth()->guard()->guest()): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                                </li>
                                <?php if(Route::has('register')): ?>
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                                    </li>
                                <?php endif; ?>
                            <?php else: ?>
                                <li class="nav-item dropdown">
                                    <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                        <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                           onclick="event.preventDefault();
                                                         document.getElementById('logout-form').submit();">
                                            <?php echo e(__('Logout')); ?>

                                        </a>
                                        <?php if(Auth::user()->is_admin <> 0): ?>
                                        <?php if(Request::is('use-as-admin')): ?>
                                        <a class="dropdown-item" href="<?php echo e(route('home')); ?>">
                                            <?php echo e(__('Xem với tư cách người dùng')); ?>

                                        </a>
                                        <?php else: ?>
                                        <a class="dropdown-item" href="<?php echo e(route('admin')); ?>">
                                            <?php echo e(__('Xem với tư cách admin')); ?>

                                        </a>
                                        <?php endif; ?>

                                        <?php endif; ?>
                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                            <?php echo csrf_field(); ?>
                                        </form>
                                    </div>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="middle-inner">
        <div class="container">
            <div class="row">
                <div class="col-lg-2 col-md-2 col-12">
                    <div class="logo">
                        <a href="<?php echo e(url('/')); ?>">ENJOY TRAVEL VN</a>
                    </div>
                    <div class="search-top">
                        <div class="top-search"><a href="#"><i class="ti-search"></i></a></div>
                        <div class="search-top">
                            <form class="search-form"  action="/search" method="get">
                                <input type="search" placeholder="Search here..." id="search" name="search">
                                <button value="search" type="submit"><i class="ti-search"></i></button>
                                <?php echo e(csrf_field()); ?>

                            </form>
                        </div>
                    </div>
                    <div class="mobile-nav"></div>
                </div>
                <div class="col-lg-8 col-md-7 col-12">
                    <div class="search-bar-top">
                        <div class="search-bar">
                            <form action="/search" method="get">
                                <input name="search" placeholder="Nhập tên sản phẩm....." type="search" id="search" name="search">
                                <button class="btnn"><i class="ti-search"></i></button>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 col-md-3 col-12">
                    <div class="right-bar">
                        <div class="sinlge-bar">
                            <a href="<?php echo e(url('/favorite-tour')); ?>" class="single-icon"><i class="fa fa-heart-o" aria-hidden="true"></i></a>
                        </div>
                        <div class="sinlge-bar">
                            <a href="<?php echo e(url('/profile')); ?>" class="single-icon"><i class="fa fa-user-circle-o" aria-hidden="true"></i></a>
                        </div>
                        <div class="sinlge-bar">
                            <a href="<?php echo e(url('/tours')); ?>" class="single-icon"><i class="ti-clipboard"></i></a>
                        </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="header-inner">
        <div class="container">
            <div class="cat-nav-head">
                <div class="row">
                    <div class="col-12">
                        <div class="menu-area">
                            <nav class="navbar navbar-expand-lg">
                                <div class="navbar-collapse">
                                    <div class="nav-inner">
                                        <ul class="nav main-menu menu navbar-nav">
                                            <li class="<?php echo e(Request::is('/') ? 'active' : ''); ?>">
                                                <a href="<?php echo e(url('/')); ?>">TRANG CHỦ</a></li>
                                            <li class="<?php echo e(Request::is('about-us') ? 'active' : ''); ?>"><a href="<?php echo e(url('/about-us')); ?>">GIỚI THIỆU</a></li>
                                            <li class="<?php echo e(Request::is('news') || Request::is('news/*') ? 'active' : ''); ?>"><a href="<?php echo e(url('/news')); ?>">TIN TỨC</a></li>
                                            <li class="<?php echo e(Request::is('product*')? 'active' : ''); ?>"><a href="<?php echo e(url('/products')); ?>">SẢN PHẨM</a>
                                            </li>

                                            <li class="<?php echo e(Request::is('contact') ? 'active' : ''); ?>"><a href="<?php echo e(url('/contact')); ?>">LIÊN HỆ</a></li>
                                            <li class="<?php echo e(Request::is('book-tour-histories') || Request::is('chat-with-admin') || Request::is('profile') ? 'active' : ''); ?>"><a href="#">KHÁC<i class="ti-angle-down"></i><span class="new">New</span></a>
                                                <ul class="dropdown">
                                                    <li><a href="<?php echo e(url('/tours')); ?>">Lịch sử đặt tour</a></>
                                                    <li><a href="<?php echo e(url('/profile')); ?>">Trang cá nhân</a></li>
                                                </ul>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>
<?php /**PATH C:\Users\Admin\Desktop\PROJECT\travel-project\resources\views/layout/header.blade.php ENDPATH**/ ?>