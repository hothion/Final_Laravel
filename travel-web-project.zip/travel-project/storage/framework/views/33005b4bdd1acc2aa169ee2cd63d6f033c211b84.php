<script src="<?php echo e(asset('js\jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('js\jquery-migrate-3.0.0.js')); ?>"></script>
<script src="<?php echo e(asset('js\jquery-ui.min.js')); ?>"></script>
<!-- Popper JS -->
<script src="<?php echo e(asset('js\popper.min.js')); ?>"></script>
<!-- Bootstrap JS -->
<script src="<?php echo e(asset('js\bootstrap.min.js')); ?>"></script>
<!-- Color JS -->
<script src="<?php echo e(asset('js/colors.js')); ?>"></script>
<!-- Slicknav JS -->
<script src="<?php echo e(asset('js\slicknav.min.js')); ?>"></script>
<!-- Owl Carousel JS -->
<script src="<?php echo e(asset('js\owl-carousel.js')); ?>"></script>
<!-- Magnific Popup JS -->
<script src="<?php echo e(asset('js\magnific-popup.js')); ?>"></script>
<!-- Fancybox JS -->
<script src="<?php echo e(asset('js\facnybox.min.js')); ?>"></script>
<!-- Waypoints JS -->
<script src="<?php echo e(asset('js\waypoints.min.js')); ?>"></script>
<!-- Countdown JS -->
<script src="<?php echo e(asset('js\finalcountdown.min.js')); ?>"></script>
<!-- Nice Select JS -->
<script src="<?php echo e(asset('js\nicesellect.js')); ?>"></script>
<!-- Ytplayer JS -->
<script src="<?php echo e(asset('js\ytplayer.min.js')); ?>"></script>
<!-- Flex Slider JS -->
<script src="<?php echo e(asset('js\flex-slider.js')); ?>"></script>
<!-- ScrollUp JS -->
<script src="<?php echo e(asset('js\scrollup.js')); ?>"></script>
<!-- Onepage Nav JS -->
<script src="<?php echo e(asset('js\onepage-nav.min.js')); ?>"></script>
<!-- Easing JS -->
<script src="<?php echo e(asset('js\easing.js')); ?>"></script>
<!-- Active JS -->
<script src="<?php echo e(asset('js\active.js')); ?>"></script>
<?php /**PATH D:\xampp\htdocs\laravel\travel-project\resources\views/layout/jquery.blade.php ENDPATH**/ ?>