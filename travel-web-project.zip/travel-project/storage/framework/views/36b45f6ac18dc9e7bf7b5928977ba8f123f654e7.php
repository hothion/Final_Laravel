<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\laravel\travel\travel-project\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>