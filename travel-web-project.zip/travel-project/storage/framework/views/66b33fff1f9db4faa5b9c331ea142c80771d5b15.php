<script>
    var msg = '<?php echo e(Session::get('alert')); ?>';
    var exist = '<?php echo e(Session::has('alert')); ?>';
    if(exist){
      alert(msg);
    }
  </script>
<?php /**PATH C:\Users\Admin\Desktop\PROJECT\travel-project\resources\views/blocks/alert.blade.php ENDPATH**/ ?>