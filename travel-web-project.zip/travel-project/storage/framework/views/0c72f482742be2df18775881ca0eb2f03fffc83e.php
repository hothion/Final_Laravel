<?php $__env->startSection('content'); ?>
<head>
    <title>TOUR ĐÃ ĐẶT</title>
</head>
<!-- Breadcrumbs -->
<div class="breadcrumbs">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="bread-inner">
                    <ul class="bread-list">
                        <li><a href="<?php echo e(url('/')); ?>">TRANG CHỦ<i class="ti-arrow-right"></i></a></li>
                        <li class="active"><a href="<?php echo e(url('/about-us')); ?>">TOUR ĐÃ ĐẶT</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End Breadcrumbs -->
<?php if(isset(Auth::user()->id)): ?>
<div class="container">
    <br>
		<div>
            <div>
                LỊCH SỬ ĐẶT TOUR
               <div>
                <div class="row">
                    <div>
                        <?php if(count($tours)<>0): ?>
                        <?php $__env->startSection('count-number'); ?>
                            <?php echo e($count = 1); ?>

                        <?php $__env->stopSection(); ?>
                        <table class="table table-striped">
                            <thead>
                              <tr>
                                <th scope="col">STT</th>
                                <th scope="col">Tên</th>
                                <th scope="col">Email</th>
                                <th scope="col">SĐT</th>
                                <th scope="col">Tour</th>
                                <th scope="col">Ngày đi</th>
                                <th scope="col">Ngày về</th>
                                <th scope="col">SL</th>
                                <th scope="col">Đơn giá</th>
                                <th scope="col">Trạng thái</th>
                              </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $tours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                <th scope="row"><?php echo e($count++); ?></th>
                                <td><?php echo e($tour->name); ?></td>
                                <td><?php echo e($tour->email); ?></td>
                                <td><?php echo e($tour->phone); ?></td>
                                <td><?php echo e($tour->titleTour); ?></td>
                                <td><?php echo e(\Carbon\Carbon::parse($tour->check_in)->format('d/m/Y')); ?></td>
                                <td><?php echo e(\Carbon\Carbon::parse($tour->check_out)->format('d/m/Y')); ?></td>
                                <td><?php echo e($tour->quantity); ?></td>
                                <td><?php echo e(number_format($tour->price)); ?>VNĐ</td>
                                <td><?php echo e($tour->status); ?></td>
                                <?php if($tour->status=="Đang chờ cuộc gọi xác nhận và vé"): ?>
                                <td>
                                    <form class="form" action="<?php echo e(route('cancel-tour',$tour->id)); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <button class="btn-dlt">Hủy</button></td>
                                    </form>
                                <?php endif; ?>
                              </tr>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                          </table>
                        <?php else: ?>
                            <div>Bạn chưa đặt bất kỳ tour nào.</div>
                        <?php endif; ?>
                    </div>

                </div>
               </div>
            </div>
		</div>
    <br>
</div>
<?php else: ?>
    <?php echo $__env->make('page/non-login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Desktop\PROJECT\travel-project\resources\views/page/tour.blade.php ENDPATH**/ ?>