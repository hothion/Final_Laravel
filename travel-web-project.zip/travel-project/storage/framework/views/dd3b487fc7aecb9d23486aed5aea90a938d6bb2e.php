<?php $__env->startSection('content'); ?>
<head>
    <title>Tin tức</title>
</head>
<!-- Breadcrumbs -->
<div class="breadcrumbs">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="bread-inner">
                    <ul class="bread-list">
                        <li><a href="<?php echo e(url('/')); ?>">TRANG CHỦ<i class="ti-arrow-right"></i></a></li>
                        <li class="active"><a href="<?php echo e(url('/news')); ?>">TIN TỨC</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End Breadcrumbs -->

<section class="blog-single section">
			<div class="container">
				<div class="row">
					<div class="col-lg-8 col-12">
						<div class="blog-single-main">
							<div class="row">
								<div class="col-12">
									<div class="image">
										<img src="<?php echo e(URL::asset($news->image)); ?>" alt="<?php echo e($news->title); ?>">
									</div>
									<div class="blog-detail">
										<h2 class="blog-title"><?php echo e($news->title); ?></h2>
										<div class="blog-meta">
											<span class="author"><a href="#"><i class="fa fa-user"></i>Đăng bởi: Admin</a><a href="#"><i class="fa fa-calendar"></i><?php echo e($news->created_at); ?></a><a href="#"><i class="fa fa-comments"></i>Bình luận (<?php echo e(count($comments)); ?>)</a></span>
										</div>
										<div class="content">
											<p><?php echo e($news->content); ?></p>
										</div>
									</div>
								</div>
								<div class="col-12">
									<div class="comments">
										<h3 class="comment-title">Bình luận (<?php echo e(count($comments)); ?>)</h3>
                                        <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cmt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<div class="single-comment">
											<img src="<?php echo e(URL::asset('images\avatars\avatar.png')); ?>" alt="#">
											<div class="content">
                                                <b><?php echo e($cmt->name); ?></b> <?php echo e($cmt->content); ?>

                                                <br>
                                                <?php echo e($cmt->created_at); ?>

											</div>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <br>
                                        <br>

									</div>
								</div>
								<div class="col-12">
									<div class="reply">
										<div class="reply-head">
                                            <br>
											<h2 class="reply-title">Để lại bình luận</h2>
											<form class="form" action="#">
												<div class="row">
													<div class="col-lg-6 col-md-6 col-12">
														<div class="form-group">
															<label>Tên của bạn<span>*</span></label>
															<input type="text" name="name" placeholder="" required="required">
														</div>
													</div>
													<div class="col-lg-6 col-md-6 col-12">
														<div class="form-group">
															<label>Email của bạn<span>*</span></label>
															<input type="email" name="email" placeholder="" required="required">
														</div>
													</div>
													<div class="col-12">
														<div class="form-group">
															<label>Bình luận của bạn<span>*</span></label>
															<textarea name="message" placeholder=""></textarea>
														</div>
													</div>
													<div class="col-12">
														<div class="form-group button">
															<button type="submit" class="btn">Gửi</button>
														</div>
													</div>
												</div>
											</form>
											<!-- End Comment Form -->
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-lg-4 col-12">
						<div class="main-sidebar">
							<div class="single-widget recent-post">
                                <h3 class="title">Bài viết gần đây</h3>
                                <?php $__currentLoopData = $news_tt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news_crl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="single-post">
									<div class="image">
										<img src="<?php echo e(URL::asset($news_crl->image)); ?>" alt="#">
									</div>
									<div class="content">
										<h5><a href="<?php echo e(url('news',$news_crl->id)); ?>"><?php echo e($news_crl->title); ?></a></h5>
										<ul class="comment">
											<li><i class="fa fa-calendar" aria-hidden="true"></i><?php echo e($news_crl->created_at); ?></li>
											<li><i class="fa fa-commenting-o" aria-hidden="true"></i>3</li>
										</ul>
									</div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




							</div>

							<div class="single-widget newsletter">
								<h3 class="title">THEO DÕI CHÚNG TÔI</h3>
								<div class="letter-inner">
									<p>Theo dõi chúng tôi để nhận được tin tức một cách nhanh nhất có thể.</p>
									<div class="col-lg-6 col-md-6 col-12">
										<div class="form-group">
                                            <label>Email của bạn<span>*</span></label>
                                            <input type="email" name="email" placeholder="" required="required">
                                        </div>
                                        <div class="form-group button">
                                            <button type="submit" class="btn">Gửi</button>
                                        </div>

									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>

        <?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel\travel-project\resources\views/page/news.blade.php ENDPATH**/ ?>