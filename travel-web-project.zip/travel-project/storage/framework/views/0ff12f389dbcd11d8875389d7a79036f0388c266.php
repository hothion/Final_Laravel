<?php $__env->startSection('content'); ?>
<head>
    <title>Lịch sử đặt tour</title>
</head>
<!-- Breadcrumbs -->
<div class="breadcrumbs">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="bread-inner">
                    <ul class="bread-list">
                        <li><a href="<?php echo e(url('/')); ?>">TRANG CHỦ<i class="ti-arrow-right"></i></a></li>
                        <li class="active"><a href="<?php echo e(url('/book-tour-histories')); ?>">LỊCH SỬ ĐẶT TOUR</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End Breadcrumbs -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel\travel-project\resources\views/page/book-tour-histories.blade.php ENDPATH**/ ?>