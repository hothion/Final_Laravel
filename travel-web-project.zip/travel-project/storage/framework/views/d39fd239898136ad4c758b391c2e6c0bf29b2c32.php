<?php $__env->startSection('content'); ?>
<head>
    <title>Chi tiết sản phẩm</title>
</head>

<div class="breadcrumbs">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="bread-inner">
                    <ul class="bread-list">
                        <li><a href="<?php echo e(url('/')); ?>">TRANG CHỦ<i class="ti-arrow-right"></i></a></li>
                        <li class="active"><a href="<?php echo e(url('/products')); ?>">TOUR<i class="ti-arrow-right"></i></a></li>
                        <li class="active">
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <a href="<?php echo e(url('/products')); ?>"><?php echo e($prds->title); ?></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End Breadcrumbs -->

<!-- Product Style -->
<section class="product-area shop-sidebar shop section">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-4 col-12">
                <div class="shop-sidebar">
                        <!-- Single Widget -->
                        <div class="single-widget category">
                            <h3 class="title">TẤT CẢ SẢN PHẨM</h3>
                            <ul class="categor-list">
                                <?php $__currentLoopData = $type_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type_prds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(route('type-product',$type_prds->id)); ?>"><?php echo e($type_prds->name); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </ul>
                        </div>

                        <div class="single-widget recent-post">
                            <h3 class="title">TOUR GẦN ĐÂY</h3>
                            <?php $__currentLoopData = $products_rlv; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prds_rlv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="single-post first">
                                    <div class="image">
                                        <a href="<?php echo e(route('product-detail',$prds_rlv->id)); ?>"><img src="<?php echo e(URL::asset($prds_rlv->image)); ?>" alt="#"></a>
                                    </div>
                                    <div class="content">
                                        <h5><a href="<?php echo e(route('product-detail',$prds_rlv->id)); ?>"><?php echo e($prds_rlv->title); ?></a></h5>
                                        <a href="<?php echo e(route('product-detail',$prds_rlv->id)); ?>"><p class="price"><?php echo e(number_format($prds_rlv->price)."VNĐ"); ?></p></a>
                                        <ul class="reviews">
                                            <li class="yellow"><i class="ti-star"></i></li>
                                            <li class="yellow"><i class="ti-star"></i></li>
                                            <li class="yellow"><i class="ti-star"></i></li>
                                            <li class="yellow"><i class="ti-star"></i></li>
                                            <li class="yellow"><i class="ti-star"></i></li>
                                        </ul>
                                    </div>
                                </div>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="container">
                                <small>
                                    <?php echo $products_rlv->links(); ?>

                                </small>

                            </div>


                        </div>
                </div>
            </div>

            <div class="col-lg-9 col-md-8 col-12">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <h1><?php echo e($prds->title); ?></h1>
                <br>
                <p>
                    <i class="fa fa-quote-left"></i>
                        <?php echo e($prds->summarize); ?>

                    <i class="fa fa-quote-right"></i>
                </p>
                <br>
                <div class="container">
                    <div class="row">
                      <div class="col">
                        <img src="<?php echo e(URL::asset($prds->image)); ?>" alt="">
                      </div>
                      <div class="col">
                        <div>
                            <div class="spacing">
                                <h5><i class="ti-money"></i>Giá:</h5>
                                <?php if($prds->on_sale<>0): ?>
                                <span style="text-decoration: line-through;"><?php echo e(number_format($prds->price)); ?>đ</span>
                                <?php else: ?>
                                <h6 style="color: rgb(253, 11, 11)"><?php echo e(number_format($prds->price)); ?>đ<span style="color:  rgb(59, 58, 58)">/1 người</span></h6>
                                <?php endif; ?>
                            </div>
                                 <?php if($prds->on_sale<>0): ?>
                                 <div class="spacing">
                                    <h5><i class="ti-money"></i>Sale:</h5>
                                    <h6 style="color: rgb(253, 11, 11)"><?php echo e(number_format($prds->price - (($prds->price*$prds->on_sale)/100))); ?>đ <span style="color: rgb(59, 58, 58)">/1 người</span></h6>
                                </div>
                                <?php endif; ?>


                            <div class="spacing">
                                <h5><i class="ti-alarm-clock"></i>Lịch trình:</h5>
                                <span><?php echo e($prds->schedule); ?></span>
                            </div>


                        </div>
                      </div>
                </div>

                <div>
                    <?php echo $prds->content; ?>

                </div>

                <br>
                <div class="col-12 spacing">

                    <form class="form" action="<?php echo e(route('add-to-favorite',$prds->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn fvr"><span>Yêu thích</button>
                    </form>
                    <form class="form-group button" action="<?php echo e(route('bookTour',$prds->id)); ?>" method="get">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn book">ĐẶT NGAY</button>
                    </form>
                </div>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</section>
<section class="shop-newsletter section">
    <div class="container">
        <div class="inner-top">
            <div class="row">
                <div class="col-lg-8 offset-lg-2 col-12">
                    <div class="inner">
                        <h4>NHẬN THÔNG BÁO TỪ CHÚNG TÔI</h4>
                        <p> Nhập email của bạn tại đây để có thể nhận được những thông báo mới nhất từ chúng tôi.</p>
                        <form action="mail/mail.php" method="get" target="_blank" class="newsletter-inner">
                            <input name="EMAIL" placeholder="Email của bạn" required="" type="email">
                            <button class="btn">GỬI</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Desktop\PROJECT\travel-project\resources\views/page/product-detail.blade.php ENDPATH**/ ?>