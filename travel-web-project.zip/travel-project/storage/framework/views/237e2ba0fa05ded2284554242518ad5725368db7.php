<header class="header shop">
    <div class="topbar">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-12 col-12">
                    <div class="top-left">
                        <ul class="list-main">
                            <li><i class="ti-mobile"></i> 0366 908 087</li>
                            <li><i class="ti-email"></i> vnenjoytravel@gmail.com</li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-8 col-md-12 col-12">
                    <div class="right-content">
                        <ul class="list-main">
                            <li><i class="ti-location-pin"></i> 99 Tô Hiến Thành, Sơn Trà, Đà Nẵng</li>
                            <li><i class="ti-alarm-clock"></i> <a href="#">24/7</a></li>
                            <li><i class="ti-user"></i> <a href="#">Tài khoản</a></li>
                            <?php if(auth()->guard()->guest()): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                                </li>
                                <?php if(Route::has('register')): ?>
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                                    </li>
                                <?php endif; ?>
                            <?php else: ?>
                                <li class="nav-item dropdown">
                                    <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                        <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                                    </a>

                                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                           onclick="event.preventDefault();
                                                         document.getElementById('logout-form').submit();">
                                            <?php echo e(__('Logout')); ?>

                                        </a>

                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                            <?php echo csrf_field(); ?>
                                        </form>
                                    </div>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="middle-inner">
        <div class="container">
            <div class="row">
                <div class="col-lg-2 col-md-2 col-12">
                    <div class="logo">
                        <a href="<?php echo e(url('/')); ?>">ENJOY TRAVEL VN</a>
                    </div>
                    <div class="search-top">
                        <div class="top-search"><a href="#0"><i class="ti-search"></i></a></div>
                        <div class="search-top">
                            <form class="search-form" action="/search" method="get">
                                <input type="search" placeholder="Search here..." id="search" name="search">
                                <button value="search" type="submit"><i class="ti-search"></i></button>
                                <?php echo e(csrf_field()); ?>

                            </form>
                        </div>
                    </div>
                    <div class="mobile-nav"></div>
                </div>
                <div class="col-lg-8 col-md-7 col-12">
                    <div class="search-bar-top">
                        <div class="search-bar">
                            <form>
                                <input name="search" placeholder="Nhập tên sản phẩm....." type="search">
                                <button class="btnn"><i class="ti-search"></i></button>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 col-md-3 col-12">
                    <div class="right-bar">
                        <div class="sinlge-bar">
                            <a href="#" class="single-icon"><i class="fa fa-heart-o" aria-hidden="true"></i></a>
                        </div>
                        <div class="sinlge-bar">
                            <a href="#" class="single-icon"><i class="fa fa-user-circle-o" aria-hidden="true"></i></a>
                        </div>
                        <div class="sinlge-bar shopping">
                            <a href="#" class="single-icon"><i class="ti-bag"></i> <span class="total-count">2</span></a>
                            <div class="shopping-item">
                                <div class="dropdown-cart-header">
                                    <span>2 TOURS</span>
                                    <a href="#">BOOK TOUR</a>
                                </div>
                                <ul class="shopping-list">
                                    <li>
                                        <a href="#" class="remove" title="Xóa đơn"><i class="fa fa-remove"></i></a>
                                        <a class="cart-img" href="#"><img src="images/places/danang.jpg" alt="#"></a>
                                        <h4><a href="#">Đà Nẵng</a></h4>
                                        <p class="quantity">1x - <span class="amount">3.200.000đ</span></p>
                                    </li>
                                    <li>
                                        <a href="#" class="remove" title="Xóa đơn"><i class="fa fa-remove"></i></a>
                                        <a class="cart-img" href="#"><img src="images\places/hoian.jpg" alt="#"></a>
                                        <h4><a href="#">Hội An</a></h4>
                                        <p class="quantity">1x - <span class="amount">3.000.000đ</span></p>
                                    </li>
                                </ul>
                                <div class="bottom">
                                    <div class="total">
                                        <span>Tổng giá</span>
                                        <span class="total-amount">6.200.200đ</span>
                                    </div>
                                    <a href="<?php echo e(url('/checkout')); ?>" class="btn animate">THANH TOÁN</a>
                                </div>
                            </div>
                            <!--/ End Shopping Item -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Header Inner -->
    <div class="header-inner">
        <div class="container">
            <div class="cat-nav-head">
                <div class="row">
                    <div class="col-12">
                        <div class="menu-area">
                            <!-- Main Menu -->
                            <nav class="navbar navbar-expand-lg">
                                <div class="navbar-collapse">
                                    <div class="nav-inner">
                                        <ul class="nav main-menu menu navbar-nav">
                                            <li class="<?php echo e(Request::is('/') ? 'active' : ''); ?>">
                                                <a href="<?php echo e(url('/')); ?>">TRANG CHỦ</a></li>
                                            <li class="<?php echo e(Request::is('about-us') ? 'active' : ''); ?>"><a href="<?php echo e(url('/about-us')); ?>">GIỚI THIỆU</a></li>
                                            <li class="<?php echo e(Request::is('news') || Request::is('news/*') ? 'active' : ''); ?>"><a href="<?php echo e(url('/news')); ?>">TIN TỨC</a></li>
                                            <li class="<?php echo e(Request::is('product*')? 'active' : ''); ?>"><a href="<?php echo e(url('/products')); ?>">SẢN PHẨM</a>
                                                
                                            </li>

                                            <li class="<?php echo e(Request::is('contact') ? 'active' : ''); ?>"><a href="<?php echo e(url('/contact')); ?>">LIÊN HỆ</a></li>
                                            <li class="<?php echo e(Request::is('book-tour-histories') || Request::is('chat-with-admin') ? 'active' : ''); ?>"><a href="<?php echo e(url('/others')); ?>">KHÁC<i class="ti-angle-down"></i><span class="new">New</span></a>
                                                <ul class="dropdown">
                                                    <li><a href="<?php echo e(url('/book-tour-histories')); ?>">Lịch sử đặt tour</a></>
                                                    <li><a href="<?php echo e(url('/chat-with-admin')); ?>">Chat với admin</a></li>
                                                </ul>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </nav>
                            <!--/ End Main Menu -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--/ End Header Inner -->
</header>
<!--/ End Header -->
<?php /**PATH D:\xampp\htdocs\laravel\travel\travel-project\resources\views/layout/header.blade.php ENDPATH**/ ?>