<?php $__env->startSection('content'); ?>
<?php echo $__env->make('blocks.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<head>
    <title>Sản phẩm</title>
</head>

<div class="breadcrumbs">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="bread-inner">
                    <ul class="bread-list">
                        <li><a href="<?php echo e(url('/')); ?>">TRANG CHỦ<i class="ti-arrow-right"></i></a></li>
                        <li class="active"><a href="<?php echo e(url('/products')); ?>">SẢN PHẨM</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<section class="product-area shop-sidebar shop section">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-4 col-12">
                <div class="shop-sidebar">

                        <div class="single-widget category">
                            <h3 class="title">TẤT CẢ SẢN PHẨM</h3>
                            <ul class="categor-list">
                                <?php $__currentLoopData = $type_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type_prds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(route('type-product',$type_prds->id)); ?>"><?php echo e($type_prds->name); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>

                        <div class="single-widget recent-post">
                            <h3 class="title">TOUR ĐƯỢC ĐẶT NHIỀU NHẤT</h3>
                            <div class="single-post first">
                                <div class="image">
                                    <img src="images/places/danang.jpg" alt="#">
                                </div>
                                <div class="content">
                                    <h5><a href="#">Da Nang</a></h5>
                                    <p class="price">3000000đ</p>
                                    <ul class="reviews">
                                        <li class="yellow"><i class="ti-star"></i></li>
                                        <li class="yellow"><i class="ti-star"></i></li>
                                        <li class="yellow"><i class="ti-star"></i></li>
                                        <li><i class="ti-star"></i></li>
                                        <li><i class="ti-star"></i></li>
                                    </ul>
                                </div>
                            </div>

                            <div class="single-post first">
                                <div class="image">
                                    <img src="images/places/dalat.jpg" alt="#">
                                </div>
                                <div class="content">
                                    <h5><a href="#">Da Lat</a></h5>
                                    <p class="price">3500000đ</p>
                                    <ul class="reviews">
                                        <li class="yellow"><i class="ti-star"></i></li>
                                        <li class="yellow"><i class="ti-star"></i></li>
                                        <li class="yellow"><i class="ti-star"></i></li>
                                        <li class="yellow"><i class="ti-star"></i></li>
                                        <li><i class="ti-star"></i></li>
                                    </ul>
                                </div>
                            </div>

                            <div class="single-post first">
                                <div class="image">
                                    <img src="images/places/hoian.jpg" alt="#">
                                </div>
                                <div class="content">
                                    <h5><a href="#">Hoi An</a></h5>
                                    <p class="price">3200000đ</p>
                                    <ul class="reviews">
                                        <li class="yellow"><i class="ti-star"></i></li>
                                        <li class="yellow"><i class="ti-star"></i></li>
                                        <li class="yellow"><i class="ti-star"></i></li>
                                        <li class="yellow"><i class="ti-star"></i></li>
                                        <li class="yellow"><i class="ti-star"></i></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                </div>
            </div>

            <div class="col-lg-9 col-md-8 col-12">
                <?php if(Request::is('products') || Request::is('products/ord-by-*')): ?>
                <div class="row">
                    <div class="col-12">
                        <div class="shop-top">
                            <div class="shop-shorter">
                                <div class="single-shorter">
                                        <form method="get" action="">
                                            <label>SẮP XẾP THEO :</label>
                                            <select name="event_edit" class="form-control form-control-lg"
                                                onChange="window.location.href='' + 'products/' +  this.options[this.selectedIndex].value">
                                                <option  value="ord-by-name">Tên</option>
                                                <option value="ord-by-price">Giá</option>
                                                <option value="ordered-a-lot">Được đặt nhiều</option>
                                            </select>
                                        </form>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php else: ?>
                <?php endif; ?>
                <?php if($products->count()<>0): ?>
                <br>
                <div>Có tất cả <b><?php echo e($products->count()); ?></b> tour.</div>
                <?php endif; ?>
                <div class="row">
                    <?php if($products->count()<>0): ?>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-6 col-12">
                        <div class="single-product">
                            <div class="product-img">
                                <a href="<?php echo e(route('product-detail',$prds->id)); ?>">
                                    <img height="200px" src="<?php echo e(URL::asset($prds->image)); ?>" alt="<?php echo e($prds->title); ?>">
                                    <img class="hover-img" src="<?php echo e(URL::asset($prds->image)); ?>" alt="<?php echo e($prds->title); ?>">
                                    <?php $__currentLoopData = $type_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type_prds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php switch($prds->id_type):
                                        case ($type_prds->id): ?>
                                            <span class="new"><?php echo e($type_prds->name); ?></span>
                                            <?php break; ?>
                                            <?php default: ?>
                                        <?php endswitch; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </a>
                                <div class="button-head">
                                    <div class="product-action">
                                        <a title="Xem thêm" href="<?php echo e(route('product-detail',$prds->id)); ?>"><i class=" ti-eye"></i><span>Xem thêm</span></a>
                                        </div>
                                    <div class="product-action-2">
                                        <a title="Đặt tour" href="#">Đặt tour</a>
                                    </div>
                                </div>
                            </div>
                            <div class="product-content">
                                <h3><a href="<?php echo e(route('product-detail',$prds->id)); ?>"><?php echo e($prds->title); ?></a></h3>
                                <div class="product-price">
                                    <div class="spacing">
                                        <span><i class="ti-money"></i>Giá:</span>
                                        <span>
                                            <?php if($prds->on_sale<>0): ?>
                                            <b style="text-decoration: line-through;">
                                                <?php echo e(number_format($prds->price)); ?>đ
                                            </b>
                                            <b style="color: red">
                                                <?php echo e(' '.number_format($prds->price - (($prds->price*$prds->on_sale)/100))); ?>đ
                                            </b>
                                            <?php else: ?>
                                                <b style="color: red">
                                                    <?php echo e(number_format($prds->price)); ?>đ
                                                </b>
                                            <?php endif; ?>
                                        </span>
                                    </div>

                                    <div class="spacing">
                                        <span><i class="ti-alarm-clock"></i>Lịch trình:</span>
                                        <span><?php echo e($prds->schedule); ?></span>
                                    </div>
                                    <div class="spacing">
                                        <form class="form" action="<?php echo e(route('add-to-favorite',$prds->id)); ?>" method="post">
											<?php echo csrf_field(); ?> <button style="padding: 0;
                                            border: none;
                                            background: none;" type="submit"><i class=" ti-heart" style="color: red"></i><span>Yêu thích</span></button>
                                        </form>
                                        <button type="button" class="btn btn-danger">BOOK NGAY</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <div>Không có sản phẩm nào.</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="shop-newsletter section">
    <div class="container">
        <div class="inner-top">
            <div class="row">
                <div class="col-lg-8 offset-lg-2 col-12">
                    <div class="inner">
                        <h4>NHẬN THÔNG BÁO TỪ CHÚNG TÔI</h4>
                        <p> Nhập email của bạn tại đây để có thể nhận được những thông báo mới nhất từ chúng tôi.</p>
                        <form action="mail/mail.php" method="get" target="_blank" class="newsletter-inner">
                            <input name="EMAIL" placeholder="Email của bạn" required="" type="email">
                            <button class="btn">GỬI</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\travel-project\resources\views/page/product.blade.php ENDPATH**/ ?>