<?php $__env->startSection('content'); ?>

<head>
    <title>Lịch sử đặt tour</title>
</head>
<!-- Breadcrumbs -->
<div class="breadcrumbs">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="bread-inner">
                    <ul class="bread-list">
                        <li><a href="<?php echo e(url('/')); ?>">TRANG CHỦ<i class="ti-arrow-right"></i></a></li>
                        <li class="active"><a href="<?php echo e(url('/book-tour-histories')); ?>">LỊCH SỬ ĐẶT TOUR</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container">
    <div id="content">
        <br>
        <form action="<?php echo e(route('bookTour')); ?>" method="POST">
        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
            <div class="row"><?php if(Session::has('thongbao')): ?><?php echo e(Session::get('thongbao')); ?><?php endif; ?></div>
            <div class="row">
                <div class="col-md-6">
                    <h4>Đặt tour</h4>
                    <div class="space20">&nbsp;</div>

                    <div class="form-block">
                        <label for="name">Check In*</label>
                        <input class="form-control" name="check_in" type="date" required>
                    </div>

                    <div class="form-block">
                        <label for="name">Check Out*</label>
                        <input class="form-control" name="check_out" type="date" required>
                    </div>

                    <div class="form-block">
                        <label for="name">Họ tên*</label>
                        <input type="text" name="name" placeholder="Họ tên" required>
                    </div>

                    <div class="form-block">
                        <label for="name">Email*</label>
                        <input type="text" name="email" placeholder="Email" required>
                    </div>

                    <div class="form-block">
                        <label for="Phone">Phone*</label>
                        <input type="text" name="phone" placeholder="phone" required>
                    </div>

                    <div class="form-block">
                        <label for="Phone">Note</label>
                        <input type="text" name="note" placeholder="note" required>
                    </div>
                </div>


                <div class="col-sm-6">
                    <div class="your-order">
                        <div class="your-order-head">
                            <h5>Tour của bạn</h5>
                        </div>
                        <div class="your-order-body" style="padding: 0px 10px">
                            <div class="your-order-item">
                               <?php $__currentLoopData = $tours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="media">
                                        <img width="25%" src="<?php echo e(URL::asset($bt->image)); ?>" alt="" class="pull-left">
                                        <br>

                                        <div class="media-body">
                                            <p class="font-large"><a
                                            href="<?php echo e(url('products-detail',$bt->id)); ?>"><?php echo e(' '); ?><?php echo e($bt->title); ?></a></p>
                                            <span class="color-gray your-order-info">Đơn giá: <?php echo e(number_format($bt->price)); ?> đồng</span>
                                            <br>
											<span class="color-gray your-order-info">Số lượng người:
                                                <input type="text" name="qty" onKeyUp="updateb(this);" /><br>
                                            </span>
                                            </div>
                                    </div>
                                    <script type="text/javascript">
                                        function updateb(inputElement)
                                        {
                                        var a = inputElement.value;
                                        var target = document.getElementById('sum');
                                        if(target != null){
                                            target.innerHTML = a*<?php echo e($bt->price); ?> + "VNĐ";
                                        }
                                        }
                                    </script>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <div class="clearfix"></div>
                              </div>

                            <div class="your-order-item">
                            <div class="cart-total text-right">Tổng tiền: <b class="cart-total-value" name="totalPrice" value="this" id="sum"></b></div>


                            <div class="clearfix"></div>
                            </div>
                            </div>
                            <button type="submit" class="btn btn-success">Book Now</button>
                            </div> <!-- .your-order -->
                </div>

            </div>
            <br>
			</form>
    </div> <!-- #content -->
</div> <!-- .container -->




<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\travel\travel-project\resources\views/page/book-tour-histories.blade.php ENDPATH**/ ?>